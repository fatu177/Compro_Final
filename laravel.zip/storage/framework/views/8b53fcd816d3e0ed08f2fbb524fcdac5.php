
<div class="about-me container">

    <div class="section-title">

        <h2>About</h2>
        <p>Learn more about me</p>
    </div>

    <div class="row">
        <div class="col-lg-4" data-aos="fade-right">
            <img src="<?php echo e(asset('images/' . $profile->image)); ?>" class="img-fluid" alt="" height="80vh">
        </div>
        <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3>WEB PROGRAMMING</h3>
            <p class="fst-italic">
                <?php echo e($profile->description); ?>

            </p>
            <div class="row">
                <div class="col-lg-6">
                    <ul>
                        <li><i class="bi bi-chevron-right"></i> <strong>Birthday:</strong>
                            <span><?php echo e(date('d F Y', strtotime($profile->birthday))); ?></span>
                        </li>
                        <li><i class="bi bi-chevron-right"></i> <strong>Website:</strong>
                            <span>www.example.com</span>
                        </li>
                        <li><i class="bi bi-chevron-right"></i> <strong>Phone:</strong>
                            <span><?php echo e($profile->phone); ?></span>
                        </li>
                        <li><i class="bi bi-chevron-right"></i> <strong>Address:</strong>
                            <span><?php echo e($profile->address); ?></span>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul>
                        <li><i class="bi bi-chevron-right"></i> <strong>Age:</strong> <span>
                                <?php
                                    $tgl = strtotime($profile->birthday);
                                    $a = date('Y') - date('Y', $tgl);
                                    if (
                                        date('m') < date('m', $tgl) ||
                                        (date('m') == date('m', $tgl) && date('d') < date('d', $tgl))
                                    ) {
                                        $a--;
                                    }
                                    echo $a;
                                ?>
                            </span>
                        </li>
                        <li><i class="bi bi-chevron-right"></i> <strong>Education:</strong>
                            <span><?php echo e($education->first()->degree); ?></span>
                        </li>
                        <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong>
                            <span><?php echo e($profile->email); ?></span>
                        </li>

                    </ul>
                </div>
            </div>
            <div class="skills container" style="background: none; padding: 3px">
                <h2>Skill</h2>
                <div class="row skills-content">
                    <div class="col-lg-6">
                        <!-- Loop PHP: Generate the first half of skills -->
                        <?php
                            $c = 0;
                            if ($skill->count() % 2 == 1) {
                                $c++;
                            }
                        ?>
                        <?php for($i = 0; $i < ($skill->count() + $c) / 2; $i++): ?>
                            <div class="progress">
                                <span class="skill"><?php echo e($skill[$i]->name); ?><i
                                        class="val"><?php echo e($skill[$i]->level); ?>%</i></span>
                                <div class="progress-bar-wrap">
                                    <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($skill[$i]->level); ?>"
                                        aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                    <div class="col-lg-6">
                        <!-- Loop PHP: Generate the second half of skills -->
                        <?php for($i = ($skill->count() + $c) / 2; $i < $skill->count(); $i++): ?>
                            <div class="progress">
                                <span class="skill"><?php echo e($skill[$i]->name); ?><i
                                        class="val"><?php echo e($skill[$i]->level); ?>%</i></span>
                                <div class="progress-bar-wrap">
                                    <div class="progress-bar" role="progressbar"
                                        aria-valuenow="<?php echo e($skill[$i]->level); ?>" aria-valuemin="0" aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
            <!-- ======= Skills  ======= -->



        </div>



    </div><!-- End Skills -->
</div>
</div>

</div>




<!-- End Counts -->



<!-- ======= Interests ======= -->


<!-- ======= Testimonials ======= -->

<!-- End Testimonials  -->
<?php /**PATH C:\xampp\htdocs\comprofinal\resources\views/home/about.blade.php ENDPATH**/ ?>