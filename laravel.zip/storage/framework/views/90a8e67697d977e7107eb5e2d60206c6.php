<div class="section-title">
    <h2>Portfolio</h2>
    <p>My Works</p>
</div>



<div class="row portfolio-container">
    <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $id = $project->id;
            $gambar = $gambar->where('id_project', $project->id);

        ?>

        <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
                <img src=" <?php echo e(asset('images/' . $gambar->first()->image)); ?> " class="img-fluid" alt="">
                <div class="portfolio-info">
                    <h4><?php echo e($project->name); ?></h4>
                    <div class="portfolio-links">
                        <a href=" <?php echo e(asset('images/' . $gambar->first()->image)); ?> " data-gallery="portfolioGallery"
                            class="portfolio-lightbox" title="App 1"><i class="bx bx-plus"></i></a>
                        <a href="{" data-gallery="portfolioDetailsGallery" data-glightbox="type: external"
                            class="portfolio-details-lightbox" title="Portfolio Details"><i class="bx bx-link"></i></a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>
<?php /**PATH C:\xampp\htdocs\comprofinal\resources\views/home/porto.blade.php ENDPATH**/ ?>