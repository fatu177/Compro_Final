<?php $__env->startSection('content'); ?>
    <?php
        $i = 0;
    ?>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $i++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($i == 0): ?>
        <div class="m-3" align="right">
            <a class="btn bg-gradient-dark mb-0" href="<?php echo e(route('profile.create')); ?>"><i
                    class="material-icons text-sm">add</i>&nbsp;&nbsp;Tambah
                Profile</a>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                        <h6 class="text-white text-capitalize ps-3">Profile</h6>
                    </div>
                </div>
                <div class="card-body px-0 pb-2">
                    <div class="" align="center">

                        <img src="<?php echo e(asset('images/' . $data->first()->image)); ?>" class="align-content-center m-3"
                            alt="" width="200px">
                    </div>
                    <div class="table-responsive p-0">

                        <table class="table align-items-center justify-content-center mb-0">

                            <thead>
                                <tr>
                                    <th
                                        class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-center">
                                        No
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Nama</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Email</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Tanggal Lahir</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        No HP</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Alamat</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Github</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        LinkedIn</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Twitter</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Facebook</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                        Instagram</th>
                                    <th
                                        class="text-uppercase text-secondary text-xxs font-weight-bolder text-center opacity-7 ps-2">
                                        Deskripsi</th>

                                    <th
                                        class="text-uppercase text-secondary text-xxs font-weight-bolder text-center opacity-7 ps-2">
                                        Aksi</th>

                                </tr>
                            </thead>
                            <tbody>
                                <span hidden><?php echo e($i = 1); ?></span>

                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 text-center"><?php echo e($i++); ?></p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1"> <?php echo e($data->name); ?> </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1"> <?php echo e($data->email); ?> </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1"> <?php echo e($data->birthday); ?> </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1 text-center">
                                                <?php echo e($data->phone); ?>

                                            </p>
                                        </td>

                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1 text-center">
                                                <?php echo e($data->address); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1 text-center">
                                                <?php echo e($data->github); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1 text-center">
                                                <?php echo e($data->linkedin); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1 text-center">
                                                <?php echo e($data->twitter); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1 text-center">
                                                <?php echo e($data->facebook); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1 text-center">
                                                <?php echo e($data->instagram); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <p class="text-sm font-weight-bold mb-0 ps-1 text-center">
                                                <?php echo e($data->description); ?>

                                            </p>
                                        </td>
                                        <td>
                                            <div class="d-flex justify-content-center">
                                                <a href="<?php echo e(route('profile.edit', $data->id)); ?>"
                                                    class="btn btn-primary btn-sm me-1">Edit</a>
                                                <form action="<?php echo e(route('profile.destroy', $data->id)); ?>" method="post"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                                                </form>

                                            </div>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\comprofinal\resources\views/profile/index.blade.php ENDPATH**/ ?>