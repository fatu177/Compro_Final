home
<?php /**PATH C:\xampp\htdocs\comprofinal\resources\views/home.blade.php ENDPATH**/ ?>