<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header"><?php echo e($title); ?></div>
        <div class="card-body">
            <form action="<?php echo e(route('gambar.update', $edit->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="row">
                    <div class="col-lg-6 col-md-6">

                        <div class="form-group mb-3">
                            <label for="">Project</label>
                            <div class="input-group input-group-outline my-3">
                                <select name="id_project" class="form-control" style="border-radius: 20px;">
                                    <option selected value="<?php echo e($edit->id_project); ?>">Pilih Project</option>
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="form-group mb-3">
                            <label for="">Gambar</label>
                            <div class="input-group input-group-outline my-3">
                                <input type="file" name="image" class="form-control" id="imageInput">
                            </div>
                            <br>
                            <img id="imagePreview" src="<?php echo e(asset('images/' . $edit->image)); ?>" class="img-preview"
                                width="200px" />
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <input type="submit" class="btn btn-primary" value="Simpan">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger">Kembali</a>
                    </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\comprofinal\resources\views/gambar/edit.blade.php ENDPATH**/ ?>