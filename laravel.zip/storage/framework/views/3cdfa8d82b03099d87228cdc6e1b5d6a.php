<div class="section-title">
    <h2>Resume</h2>
</div>
<h3 class="resume-title">Education</h3>
<div class="row">

    <div class="col-lg-6">

        <!-- Loop PHP: Generate the first half of educations -->
        <?php
            $c = 0;
            if ($education->count() % 2 == 1) {
                $c++;
            }
        ?>
        <?php for($i = 0; $i < ($education->count() + $c) / 2; $i++): ?>
            <div class='resume-item'>



                <h5>
                    <?php echo e(date('Y', strtotime($education[$i]->start_date))); ?> -
                    <?php if(date('d-m-Y', strtotime($education[$i]->end_date)) == date('d-m-Y', $education[$i]->updated_at->timestamp)): ?>
                        Present
                    <?php else: ?>
                        <?php echo e(date('Y', strtotime($education[$i]->end_date))); ?>

                    <?php endif; ?>
                </h5>

                <h4><?php echo e($education[$i]->school_name); ?></h4>
                <p><em><?php echo e($education[$i]->degree); ?> <?php echo e($education[$i]->field_of_study); ?></em></p>
                <p><?php echo e($education[$i]->description); ?></p>
            </div>
        <?php endfor; ?>
    </div>
    <div class="col-lg-6">
        <!-- Loop PHP: Generate the second half of educations -->
        <?php for($i = ($education->count() + $c) / 2; $i < $education->count(); $i++): ?>
            <div class='resume-item'>



                <h5>
                    <?php echo e(date('Y', strtotime($education[$i]->start_date))); ?> -
                    <?php if(date('d-m-Y', strtotime($education[$i]->end_date)) == date('d-m-Y', $education[$i]->updated_at->timestamp)): ?>
                        Present
                    <?php else: ?>
                        <?php echo e(date('Y', strtotime($education[$i]->end_date))); ?>

                    <?php endif; ?>
                </h5>
                <h4><?php echo e($education[$i]->school_name); ?></h4>
                <p><em><?php echo e($education[$i]->degree); ?> <?php echo e($education[$i]->field_of_study); ?></em></p>
                <p><?php echo e($education[$i]->description); ?></p>
            </div>
        <?php endfor; ?>
    </div>
</div>

<h3 class="resume-title">Experiene</h3>
<div class="row">

    <div class="col-lg-6">

        <!-- Loop PHP: Generate the first half of educations -->
        <?php
            $c = 0;
            if ($experience->count() % 2 == 1) {
                $c++;
            }
        ?>
        <?php for($i = 0; $i < ($experience->count() + $c) / 2; $i++): ?>
            <div class='resume-item'>


                <h5>
                    <?php echo e(date('d F Y', strtotime($experience[$i]->start_date))); ?> -
                    <?php if(date('d-m-Y', strtotime($experience[$i]->end_date)) == date('d-m-Y', $experience[$i]->updated_at->timestamp)): ?>
                        Present
                    <?php else: ?>
                        <?php echo e(date('Y', strtotime($experience[$i]->end_date))); ?>

                    <?php endif; ?>
                </h5>
                <h4><?php echo e($experience[$i]->company_name); ?></h4>
                <p><em><?php echo e($experience[$i]->position); ?></em></p>
                <p><?php echo e($experience[$i]->description); ?></p>
            </div>
        <?php endfor; ?>
    </div>
    <div class="col-lg-6">
        <!-- Loop PHP: Generate the second half of experiences -->
        <?php for($i = ($experience->count() + $c) / 2; $i < $experience->count(); $i++): ?>
            <div class='resume-item'>



                <h5>
                    <?php echo e(date('d F Y', strtotime($experience[$i]->start_date))); ?> -
                    <?php if(date('d-m-Y', strtotime($experience[$i]->end_date)) == date('d-m-Y', $experience[$i]->updated_at->timestamp)): ?>
                        Present
                    <?php else: ?>
                        <?php echo e(date('Y', strtotime($experience[$i]->end_date))); ?>

                    <?php endif; ?>
                </h5>
                <h4><?php echo e($experience[$i]->company_name); ?></h4>
                <p><em><?php echo e($experience[$i]->position); ?></em></p>
                <p><?php echo e($experience[$i]->description); ?></p>
            </div>
        <?php endfor; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\comprofinal\resources\views/home/resume.blade.php ENDPATH**/ ?>